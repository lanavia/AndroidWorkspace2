package com.example.android.clase9cp

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        //PRIMERA PARTE DE LA CLASE COMENTADA

     /*   //ahora en las siguientes 3 lineas se esta guardando
        //sin necesidad de apretar el boton btnSave
        var sp = getSharedPreferences("spArchivo", Context.MODE_PRIVATE)
        var mensaje = sp.getString("mensaje", "$")
        lblMsg.text = mensaje


        btnSave.setOnClickListener {
            //se crea shared preference, lo que esta entre comillas es el nombre del archivo
            var sp = getSharedPreferences("spArchivo", Context.MODE_PRIVATE)
            //
            var editor = sp.edit()
            //se le da nombre a la variable que tomara el texto a editar
            var mensaje = txtMensaje.text.toString()
            //se indica si lo que se grabara es string o int
            editor.putString("mensaje",txtMensaje.text.toString())
            //el sgte ejemplo es con int
            editor.putInt("id",9999)
            // se pone commit para que se apliquen los cambios
            editor.commit()
            //se muestra toast que dice que está ok el cambio
            Toast.makeText(this,"Mensaje escrito OK",Toast.LENGTH_SHORT).show()

        }*/

        btnGuardar.setOnClickListener {

            try {
                //crea un archivo de extension txt
                var archivo = openFileOutput("archivo.txt",Context.MODE_PRIVATE)
            }
            catch (e:Exception) {

            }
        }


    }


}
